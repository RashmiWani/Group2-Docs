﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
//using System.Windows.Controls;
using System.Drawing;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using ePES.BL;
using ePES.Entity;
using System.IO;

namespace ePES.PL
{
    /// <summary>
    /// Interaction logic for CustomerDoc.xaml
    /// </summary>
    public partial class CustomerDoc : Window
    {
        public CustomerDoc()
        {
            InitializeComponent();
        }


        public BitmapImage byteArrayToImage(byte[] imgArray)
        {
            MemoryStream ms = new MemoryStream(imgArray);

            BitmapImage bitm = new BitmapImage();
            bitm.BeginInit();
            bitm.StreamSource = ms;
            bitm.EndInit();
            return bitm;
        }

        private void btnShow_Click_1(object sender, RoutedEventArgs e)
        {

            ImageEntity ie = new ImageEntity();
            //ie.customerID = 5003;
            //ie.policyNumber = 13;

            ie.customerID =Convert.ToInt32( txtCIDCD.Text);
            ie.policyNumber = Convert.ToInt32(txtPNCD.Text);

            DataTable dtImg = PolicyValidations.RetrieveImage_BL(ie);

            DataRow dr = dtImg.Rows[0];



            byte[] imgarr = (byte[])dr["img"];
                    

            BitmapImage bi = byteArrayToImage(imgarr);
            imgbox.Source = bi;
        }
    }
}
