﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ePES.Entity
{
    //public class PolicyEntity
    //{
    //}
    public class LoginCredentials
    {
        public string loginID { get; set; }
        public string userpassword { get; set; }
        public string userType { get; set; }
    }

    public class Endorsements
    {
        public int transactionID { get; set; }
        public int customerID { get; set; }
        public int policyNumber { get; set; }
        public string policyName { get; set; }
        public string productLine { get; set; }
        public string customerName { get; set; }
        public string customerAddress { get; set; }
        public string customerTelephone { get; set; }
        public string customerGender { get; set; }
        public DateTime customerDOB { get; set; }
        public string customerSmoking { get; set; }
        public string nomineeName { get; set; }
        public string nomineeRelation { get; set; }
        public string premiumFrequency { get; set; }       
      //  public string docPath { get; set; }
        public string statusEndo { get; set; }

    }

    public class EndorsementsTemp
    {
        public int transactionID { get; set; }
        public int customerID { get; set; }
        public int policyNumber { get; set; }
        public string policyName { get; set; }
        public string productLine { get; set; }
        public string customerName { get; set; }
        public string customerAddress { get; set; }
        public string customerTelephone { get; set; }
        public string customerGender { get; set; }
        public DateTime customerDOB { get; set; }
        public string customerSmoking { get; set; }
        public string nomineeName { get; set; }
        public string nomineeRelation { get; set; }
        public string premiumFrequency { get; set; }
        public string docPath { get; set; }
        public string statusEndo { get; set; }
       
    }

    public partial class Customer
    {
        public int customerID { get; set; }
        public string loginID { get; set; }
        public string customerName { get; set; }
        public string customerAddress { get; set; }
        public string customerTelephone { get; set; }
        public string customerGender { get; set; }
        public DateTime customerDOB { get; set; }
        public string customerSmoking { get; set; }
        public string customerHobbies { get; set; }
        public string nomineeName { get; set; }
        public string nomineeRelation { get; set; }
        public string userType { get; set; }
    }

    public partial class InsuranceProduct
    {
        public int productID { get; set; }
        public string productLine { get; set; }
    }

    public partial class Policy
    {
        public int policyNumber { get; set; }
        public string policyName { get; set; }
        public string policyDetails { get; set; }
        public Nullable<int> productID { get; set; }
    }

    public partial class ImageEntity
    {
        public int customerID { get; set; }
        public int policyNumber { get; set; }
        public byte[] picture { get; set; }
    }
}
