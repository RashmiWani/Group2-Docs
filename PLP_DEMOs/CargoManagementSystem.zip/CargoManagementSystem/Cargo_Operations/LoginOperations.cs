﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CargoEntities;
using Cargo_Exception;
using System.Data.SqlClient;
using System.Configuration;

namespace Cargo_Operations
{
    public class LoginOperations
    {
        
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public LoginOperations()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        }

        public int SelectEmpDetails(int empId, string Pwd)
        {
            List<Cargo_Employee> EmpList = new List<Cargo_Employee>();
            int isTrue = 0;
            try
            {
                cmd = new SqlCommand("select EmpId from group2cargo.EmployeeLogin where EmpId = '"+ empId +"' and EmpPwd = "+ Pwd, cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Cargo_Employee emp = new Cargo_Employee();
                    emp.EmployeeId = Convert.ToInt32(dr[0]);
                     isTrue = 1;
                }
                

            }
            catch(CargoException)
            {
                throw;
            }
            catch(Exception)
            {
                throw;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
            return isTrue;

        }
    }
}
