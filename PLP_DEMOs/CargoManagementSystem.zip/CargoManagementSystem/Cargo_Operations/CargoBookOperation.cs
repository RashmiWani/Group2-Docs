﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CargoEntities;
using Cargo_Exception;
using System.Data.SqlClient;
using System.Configuration;

namespace Cargo_Operations
{
    public class CargoBookOperation
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public CargoBookOperation()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        }

        public List<Cargo_OrderDetail> SelectAll()
        {
            List<Cargo_OrderDetail> order = new List<Cargo_OrderDetail>();
            try
            {
                cmd = new SqlCommand("select * from group2cargo.OrderDetails", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                while(dr.Read())
                {
                    Cargo_OrderDetail objectorder = new Cargo_OrderDetail();
                    objectorder.OrderId = Convert.ToInt32(dr[0]);
                    objectorder.Order_CustId = Convert.ToInt32(dr[1]);
                    objectorder.Order_ProdId = Convert.ToInt32(dr[2]);
                    objectorder.Quantity= Convert.ToInt32(dr[3]);
                    objectorder.Total_Weight= Convert.ToInt32(dr[4]);
                    objectorder.ToatalAmount = Convert.ToDouble(dr[5]);
                    objectorder.Order_SourceId = Convert.ToInt32(dr[6]);
                    objectorder.Order_DestinationId = Convert.ToInt32(dr[7]);
                    objectorder.DestAddress = (dr[8]).ToString();
                    objectorder.FlightNo = (dr[9]).ToString();
                    objectorder.StatusInfo = (dr[10]).ToString();

                    //objectorder.StatusInfo = (Status)Enum.Parse((typeof(Status),dr[10]));
                    objectorder.OrderDate = Convert.ToDateTime(dr[11]);
                    objectorder.DeliverDate = Convert.ToDateTime(dr[12]);
                    order.Add(objectorder);
                }
            }
            catch (CargoException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
            return order;
        }

        public List<Cargo_OrderDetail> SearchWith(int Id)
        {
            List<Cargo_OrderDetail> order = new List<Cargo_OrderDetail>();
            try
            {
                cmd = new SqlCommand("(select * from group2cargo.OrderDetails where OrderId = '"+Id+"')", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Cargo_OrderDetail objectorder = new Cargo_OrderDetail();
                    objectorder.OrderId = Convert.ToInt32(dr[0]);
                    objectorder.Order_CustId = Convert.ToInt32(dr[1]);
                    objectorder.Order_ProdId = Convert.ToInt32(dr[2]);
                    objectorder.Quantity = Convert.ToInt32(dr[3]);
                    objectorder.Total_Weight = Convert.ToInt32(dr[4]);
                    objectorder.ToatalAmount = Convert.ToDouble(dr[5]);
                    objectorder.Order_SourceId = Convert.ToInt32(dr[6]);
                    objectorder.Order_DestinationId = Convert.ToInt32(dr[7]);
                    objectorder.DestAddress = (dr[8]).ToString();
                    objectorder.FlightNo = (dr[9]).ToString();
                    objectorder.StatusInfo = (dr[10]).ToString();

                    //objectorder.StatusInfo = (Status)Enum.Parse((typeof(Status),dr[10]));
                    objectorder.OrderDate = Convert.ToDateTime(dr[11]);
                    objectorder.DeliverDate = Convert.ToDateTime(dr[12]);
                    order.Add(objectorder);
                }
            }
            catch (CargoException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
            return order;
        }

        public double getPlacePrice(int id1, int id2)
        {
            double placeprice = 0;
            try
            {
                cmd = new SqlCommand("select PlacePrice from PlacesPrice where SourceId = '" + id1 + "' and DestinationId '" + id2 + "'",cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read()) ;
                {
                    placeprice = Convert.ToDouble(dr[0]);
                }
            }
            catch(CargoException ex)
            {
                throw ex;
            }
            catch(Exception ex1)
            {
                throw ex1;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }

            return placeprice;

        }

        public int Insert(Cargo_OrderDetail order)
        {
            int no = 0;
            try
            {
                cmd = new SqlCommand("Insert into group2cargo.OrderDetails(OrderCustId, OrderProdId, Quantity, OrderWeight, TotalAmount,OrderSourceId,OrderDestinationId, DestinationAddress, FlightNo, StatusInfo, OrderDate, DeliveryDate) values('"+ order.Order_CustId+ "','"+order.Order_ProdId+"','"+order.Quantity+"','"+ order.Total_Weight+"','"+order.ToatalAmount+"','"+order.Order_SourceId+"','"+order.Order_DestinationId+"','"+order.DestAddress+"','"+order.FlightNo+"','"+order.StatusInfo+"','"+order.OrderDate+"','"+order.DeliverDate+"')",cn);
                cn.Open();
                no = cmd.ExecuteNonQuery();
            }
            catch (CargoException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                cn.Close();
            }
            return no;
        }
        public int Update(Cargo_OrderDetail order)
        {
            int no = 0;
            try
            {
                cmd = new SqlCommand("update group2cargo.OrderDetails set OrderCustId = '"+order.Order_CustId+"', OrderProdId = '"+order.Order_ProdId+"', Quantity = '"+order.Quantity+"', OrderWeight = '"+order.Total_Weight+"', TotalAmount = '"+order.ToatalAmount+"',OrderSourceId='"+order.Order_SourceId+"',OrderDestinationId = '"+order.Order_DestinationId+"', DestinationAddress = '"+order.DestAddress+"', FlightNo = '"+order.FlightNo+"', StatusInfo = '"+order.StatusInfo+"', OrderDate = '"+order.OrderDate+"', DeliveryDate = '"+order.DeliverDate+"') ",cn);
                cn.Open();
                no = cmd.ExecuteNonQuery();
            }
            catch (CargoException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                cn.Close();
            }
            return no;
        }
        public int Delete(int Id)
        {
            int no = 0;
            try
            {
                cmd = new SqlCommand("delete group2cargo.OrderDetails where OrderId = " +Id, cn );
                cn.Open();
                no = cmd.ExecuteNonQuery();
            }
            catch (CargoException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                cn.Close();
            }
            return no;
        }




    }
}
