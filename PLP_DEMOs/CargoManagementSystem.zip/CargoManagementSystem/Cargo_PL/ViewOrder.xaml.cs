﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Cargo_Operations;
using Cargo_Validation;
using CargoEntities;

namespace Cargo_PL
{
    /// <summary>
    /// Interaction logic for ViewOrder.xaml
    /// </summary>
    public partial class ViewOrder : Page
    {
       // CargoBookOperation bll = null;

        public ViewOrder()
        {
            //InitializeComponent();
            //bll = new CargoBookOperation();
            //List<Cargo_OrderDetail> studs = bll.SelectAll();
            //dg_ViewOrders.ItemsSource = studs;


        }
    }
}
