﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CargoEntities;
using Cargo_Exception;
using Cargo_Operations;
using System.Text.RegularExpressions;

namespace Cargo_Validation
{
    class LoginEmployeeValidation
    {
        LoginOperations objLoginop = null;
        public LoginEmployeeValidation()
        {
            objLoginop = new LoginOperations();
        }

        public static bool ValidateLogin(Cargo_Employee emp)
        {
            bool validate = true;
            StringBuilder message = new StringBuilder();
            try
            {
                if (!Regex.IsMatch(emp.EmployeePwd, "(?!^[0-9]*$)(?!^[a-zA-Z]*$)^([a-zA-Z0-9]{8,15})$"))
                {
                    message.Append("Employee Pasword should match this\n");
                    validate = false;
                }
            }
            catch(CargoException)
            {
                throw;
            }
            catch(Exception)
            {
                throw;
            }
            return validate;

        }
        public bool LoginDetailValidDb(Cargo_Employee emp1)
        {
            bool Loginvalid = true;
            try
            { 
                Loginvalid = ValidateLogin(emp1);
                if (Loginvalid == true)
                {
                    objLoginop.SelectEmpDetails(emp1.EmployeeId, emp1.EmployeePwd);
                    Loginvalid = true;
                }
            }
            catch(CargoException ex)
            {
                throw ex;
            }
            catch(Exception)
            {
                throw;
            }
            return Loginvalid;
        }
    }
}
