﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CargoEntities;
using Cargo_Exception;
using Cargo_Operations;
namespace Cargo_Validation
{
    public class CargoValidate
    {
        CargoBookOperation objoperation = null;
        public CargoValidate()
        {
            objoperation = new CargoBookOperation();
        }

        public double Calculate(int TotalWeight, Cargo_PlacesPrice order)
        {
            double PlacePrice = objoperation.getPlacePrice(order.SourceId, order.DestinationId);
            double TotalAmount = (TotalWeight * 100) + PlacePrice;
            return TotalAmount;
            
        }

        public int Book(Cargo_OrderDetail order)
        {
            int no = 0;
            try
            {
                no = objoperation.Insert(order);
            }
            catch(CargoException)
            {
                throw;
            }
            catch(Exception)
            {
                throw;
            }
            return no;
        }

        public List<Cargo_OrderDetail> GetAll()
        {
            List<Cargo_OrderDetail> order = null;
            try
            {
                order = objoperation.SelectAll();
            }
            catch(CargoException )
            {
                throw;
            }
            catch(Exception)
            {
                throw;
            }
            return order;
        }

        public int Edit(Cargo_OrderDetail order)
        {
            int no = 0;
            try
            {
                no = objoperation.Update(order);
            }
            catch (CargoException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return no;
        }

        public int Remove(int id)
        {
            int no = 0;
            try
            {
                no = objoperation.Delete(id);
            }
            catch(CargoException)
            {
                throw;
            }
            catch(Exception)
            {
                throw;
            }
            return no;
        }


    }
}
