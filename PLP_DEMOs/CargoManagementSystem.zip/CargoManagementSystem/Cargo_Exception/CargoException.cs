﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cargo_Exception
{
    public class CargoException:Exception
    {
        public CargoException(string errMsg):base(errMsg)
        {

        }
    }
}
