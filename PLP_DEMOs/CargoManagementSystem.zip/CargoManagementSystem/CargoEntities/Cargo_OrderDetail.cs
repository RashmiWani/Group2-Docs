﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CargoEntities
{
   public class Cargo_OrderDetail
    {
        public int OrderId { get; set; }
        public int Order_CustId { get; set; }//
        public int Order_ProdId { get; set; }//
        public int Quantity { get; set; }
        public int Total_Weight { get; set; }
        public double ToatalAmount { get; set; }
        public int Order_SourceId { get; set; }//
        public int Order_DestinationId { get; set; }//
        public string DestAddress { get; set; }
        
        public string FlightNo { get; set; }
        public string StatusInfo { get; set; }
        // public Status StatusInfo { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime DeliverDate { get; set; }
       

    }
    public enum Status
    {
        Confirmed, Intransit, Delivered 
    }

}
