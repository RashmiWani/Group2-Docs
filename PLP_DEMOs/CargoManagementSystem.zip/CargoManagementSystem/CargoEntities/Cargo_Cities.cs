﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CargoEntities
{
    public class Cargo_Cities
    {
        public int CityId { get; set; }
        public string CityName { get; set; }
        public string State { get; set; }
        
    }
}
