﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CargoEntities
{
    public class Cargo_PlacesPrice
    {
        public int SourceId { get; set; }
        public int DestinationId { get; set; }
        public double PlacePrice { get; set; }
    }
}
