﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CargoEntities
{
    public class Cargo_CustomerDetail
    {
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string CustomerAddresss { get; set; }
        public string PhoneNo { get; set; }
        public string CustomerCity { get; set; }
        public string CustomerEmail { get; set; }

    }
}
