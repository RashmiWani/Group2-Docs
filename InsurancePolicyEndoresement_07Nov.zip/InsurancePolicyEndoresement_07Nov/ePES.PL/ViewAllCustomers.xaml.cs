﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using System.Data.SqlClient;
using System.Data;
using ePES.Entity;
using ePES.Exceptions;
using ePES.BL;

namespace ePES.PL
{
    /// <summary>
    /// Interaction logic for ViewAllCustomers.xaml
    /// </summary>
    public partial class ViewAllCustomers : Window
    {
        public ViewAllCustomers()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Endorsements ed = new Endorsements();
            PolicyValidations pv = new PolicyValidations();
            try
            {
                if (true)
                {
                    DataTable dtEmp = pv.GetAllCust_BL(ed);

                    //  DataTable dtEmp = PolicyValidations.GetPolicy_BLL(c_id, c_dob, c_pn, c_name);
                    dgEndo.ItemsSource = dtEmp.DefaultView;
                }
            }
            catch (PolicyExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {

                MessageBox.Show(ex.Message);
            }

            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
}
