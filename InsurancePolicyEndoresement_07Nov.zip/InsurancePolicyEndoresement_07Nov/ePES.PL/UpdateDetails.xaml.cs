﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ePES.Entity;
using ePES.Exceptions;
using ePES.BL;

using System.Data;
using System.Data.SqlClient;


namespace ePES.PL
{
    /// <summary>
    /// Interaction logic for UpdateDetails.xaml
    /// </summary>
    public partial class UpdateDetails : Window
    {
        public UpdateDetails()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            cbPremiumPaymentFrequency.Items.Add("MONTHLY");
            cbPremiumPaymentFrequency.Items.Add("QUATERLY");
            cbPremiumPaymentFrequency.Items.Add("HALF-YEARLY");
            cbPremiumPaymentFrequency.Items.Add("ANNUALLY");
            rbMale.IsChecked = true;
            rbNonSmoker.IsChecked = true;
            //------------------------------------------------------------------

            MainWindow mw = new MainWindow();
            // int empid = Convert.ToInt32(mw.txt_ID_Search.Text);

            int id = Convert.ToInt32(txtcustomerID.Text);
            int pn = Convert.ToInt32(txtPolicyNumber.Text);
            PolicyValidations validationObj1 = new PolicyValidations();
            DataTable sEd = validationObj1.GetEndoPermanent_BL(id, pn);

            DataRow dr = sEd.Rows[0];

            if ((!dr.IsNull("customerID")) && (!dr.IsNull("policyNumber")))
            {
                txtTransactionID.Text = dr["transactionID"].ToString();

                txtPolicyName.Text = dr["policyName"].ToString();

                txtProductLine.Text = dr["productLine"].ToString();

                txtInsuredName.Text = dr["customerName"].ToString();

                txtAddress.Text = dr["customerAddress"].ToString();

                txtTelephone.Text = dr["customerTelephone"].ToString();

                txtNomineeName.Text = dr["nomineeName"].ToString();

                txtNomineeRelation.Text = dr["nomineeRelation"].ToString();
            }
            //else
            //    MessageBox.Show("No Records found with Emp Id : " + empid);


        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //PolicyValidations pv = new PolicyValidations();
                Endorsements newEsm = new Endorsements();
                PolicyValidations polval = new PolicyValidations();

                //     newEsm.transactionID = Convert.ToInt32(txtTransactionID.Text);
                newEsm.customerID = Convert.ToInt32(txtcustomerID.Text);

                newEsm.policyNumber = Convert.ToInt32(txtPolicyNumber.Text);

                newEsm.policyName = txtPolicyName.Text;

                newEsm.productLine = txtProductLine.Text;

                newEsm.customerName = txtInsuredName.Text;

                newEsm.customerAddress = txtAddress.Text;

                newEsm.customerTelephone = txtTelephone.Text;

                newEsm.nomineeName = txtNomineeName.Text;

                newEsm.nomineeRelation = txtNomineeRelation.Text;

                newEsm.premiumFrequency = cbPremiumPaymentFrequency.Text;

                if (PolicyValidations.ValidateEndorsementsTemp(newEsm) == true)
                {
                    if (rbFemale.IsChecked == true)
                        newEsm.customerGender = "F";
                    else if (rbMale.IsChecked == true)
                        newEsm.customerGender = "M";


                    if (txtDOB.Text == string.Empty)
                    {
                        newEsm.customerDOB = DateTime.MinValue;               //Convert.ToDateTime("01/01/1001");
                    }
                    else
                    {
                        newEsm.customerDOB = Convert.ToDateTime(txtDOB.Text);
                    }

                    //newEsm.customerDOB = Convert.ToDateTime(txtDOB.Text);


                    if (rbNonSmoker.IsChecked == true)
                        newEsm.customerSmoking = "Smoker"; //rbNonSmoker.Content.ToString();
                    else if (rbSmoker.IsChecked == true)
                        newEsm.customerSmoking = "Non-Smoker"; //rbSmoker.Content.ToString();

                    newEsm.nomineeName = txtNomineeName.Text;

                    newEsm.nomineeRelation = txtNomineeRelation.Text;

                    if (cbPremiumPaymentFrequency.SelectedValue.ToString() == null)
                    {
                        newEsm.premiumFrequency = "";
                    }
                    else
                    {
                        newEsm.premiumFrequency = cbPremiumPaymentFrequency.SelectedValue.ToString();
                    }

                    newEsm.statusEndo = "PENDING";
                    int succ;

                    succ = PolicyValidations.InsertEndoPermanent_BL(newEsm);

                    if (succ > 0)
                    {
                        UpdateConfirm uc = new UpdateConfirm();

                        uc.txtUcustomerID.Text = txtcustomerID.Text;
                        uc.txtUpolicyNumber.Text = txtPolicyNumber.Text;

                        uc.Show();
                    }
                    else
                    {
                        MessageBox.Show("Unable to process request");
                    }
                }
            }

            catch (PolicyExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {

                MessageBox.Show(ex.Message);
            }

            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

            //  pv.ValidateEndorsementsTemp(newEsm);
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
