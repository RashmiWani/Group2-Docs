﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using System.Data.SqlClient;
using System.Data;
using ePES.Entity;
using ePES.Exceptions;
using ePES.BL;

namespace ePES.PL
{
    /// <summary>
    /// Interaction logic for ViewAllCustomers.xaml
    /// </summary>
    public partial class ViewAllCustomers : Window
    {
        public ViewAllCustomers()
        {
            InitializeComponent();
        }


        // display the endorsement in the grid view
        private void btnDisplay_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                PolicyValidations bblObj = new PolicyValidations();
                DataTable dtEndorse = bblObj.LoadEndorseAdmin_BLL();
                dgEndorsement.ItemsSource = dtEndorse.DefaultView;

            }
            catch (SqlException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dgEndorsement_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid dg = (DataGrid)sender;
            DataRowView rw_selected = dg.SelectedItem as DataRowView;
            if (rw_selected != null)
            {
                txtCID.Text = rw_selected["customerID"].ToString();
                txtCustAddress.Text = rw_selected["customerAddress"].ToString();
                txtCustDOB.Text = rw_selected["customerDOB"].ToString();
                txtCustGender.Text = rw_selected["customerGender"].ToString();
                txtCustName.Text = rw_selected["customerName"].ToString();
                txtCustSmoke.Text = rw_selected["customerSmoking"].ToString();
                txtCustTelephone.Text = rw_selected["customerTelephone"].ToString();
                txtNomineeName.Text = rw_selected["nomineeName"].ToString();
                txtNomineeRelation.Text = rw_selected["nomineeRelation"].ToString();
                txtPolicyName.Text = rw_selected["policyName"].ToString();
                txtPolicyno.Text = rw_selected["policyNumber"].ToString();
                txtPremiumFreq.Text = rw_selected["premiumFrequency"].ToString();
                txtProductLine.Text = rw_selected["productLine"].ToString();
                txtStatus.Text = rw_selected["statusEndo"].ToString();
            }
        }

        private void btnAccept_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                PolicyValidations bllObj = new PolicyValidations();
                EndorsementsTemp newEndorse = new EndorsementsTemp();

                newEndorse.customerID = Convert.ToInt32(txtCID.Text);
                newEndorse.customerName = txtCustName.Text;
                newEndorse.customerAddress = txtCustAddress.Text;
                newEndorse.customerGender = txtCustGender.Text;
                newEndorse.customerDOB = Convert.ToDateTime(txtCustDOB.Text);
                newEndorse.customerSmoking = txtCustSmoke.Text;
                newEndorse.customerTelephone = txtCustTelephone.Text;
                newEndorse.nomineeName = txtNomineeName.Text;
                newEndorse.nomineeRelation = txtNomineeRelation.Text;
                newEndorse.policyName = txtPolicyName.Text;
                newEndorse.policyNumber = Convert.ToInt32(txtPolicyno.Text);
                newEndorse.premiumFrequency = txtPremiumFreq.Text;
                newEndorse.productLine = txtProductLine.Text;
                newEndorse.statusEndo = txtStatus.Text;

                int rowAffected = bllObj.UpdateEndorsement_BLL(newEndorse);
                if (rowAffected > 0)
                {
                    MessageBox.Show("User Endorsement Approved");
                }
                else
                    MessageBox.Show("User Endorsement not accepted");

            }
            catch (SqlException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnReject_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                PolicyValidations bllObj = new PolicyValidations();
                int cID = Convert.ToInt32(txtCID.Text);

                int rowAffected = bllObj.DeleteEndorseAdmin_BLL(cID);
                if (rowAffected > 0)
                {
                    txtCID.Clear();
                    txtCustName.Clear();
                    txtCustAddress.Clear();
                    txtCustDOB.Clear();
                    txtCustGender.Clear();
                    txtCustSmoke.Clear();
                    txtCustTelephone.Clear();
                    txtNomineeName.Clear();
                    txtNomineeRelation.Clear();
                    txtPolicyName.Clear();
                    txtPolicyno.Clear();
                    txtPremiumFreq.Clear();
                    txtProductLine.Clear();
                    txtStatus.Clear();

                    MessageBox.Show("Endorsement Request rejected");
                }
                else
                {
                    MessageBox.Show("No Endorsement Found");
                }
            }
            catch (PolicyExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void btnDoc_Click(object sender, RoutedEventArgs e)
        {
            CustomerDoc cd = new CustomerDoc();
            cd.Show();
        }
    }
}

